#pragma once
#include <string>

//created enums for degree program types
enum DegreeProgram {
    SECURITY,
    NETWORK,
    SOFTWARE
};
